# Sonic Riders: Zero Gravity Calculator
made by arielus05

## the purpose:
- to make it a bit easier to add up all your track times for story mode and
- to present the information in an easy and readable way

## instructions:
1. extract SRZGTimeCalc.zip
2. double click and run launch_program.bat
3. follow instructions on command prompt

## notes:
1. this program is **open-source**
2. the **javadoc** (SRZGTimeCalc.html) has every field/method documented in the program
2. every time the program is run, times.txt **resets** to being blank
3. idk what else to add here :v

## WIP/ideas:
1. track time editing
2. livesplit integration (read off screen to grab IGT that way)

## conclusion
i hope players find use in this program :D
- ill add more functionality to this program in the future
- **PLEASE** tell me if there are any errors/crashes/logic issues that occur while running the program
- and also please give me tips/suggestions i will greatly appreciate them!
### my discord (contact): arielus05